The url of static website hosted is:

http://d2pcdm21kv9o2s.cloudfront.net/index.html

Name of Website:-

udacity-websitemj

Word Document Containing all screenshots 

udacity-websitemj.docx


